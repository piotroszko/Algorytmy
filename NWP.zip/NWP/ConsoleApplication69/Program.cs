﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication69
{
    class Program
    {
        static string WypiszNajWspPod(int[,] COS, string string1, string string2, int i, int j)
        {
            if (i == 0 || j == 0) return "";
            if (string1[i - 1] == string2[j - 1]) return WypiszNajWspPod(COS, string1, string2, i - 1, j - 1) + string1[i - 1];
            if (COS[i, j - 1] > COS[i - 1, j]) return WypiszNajWspPod(COS, string1, string2, i, j - 1);
            else return WypiszNajWspPod(COS, string1, string2, i - 1, j);
        }
        static int[,] NajWspPod(string string1, string string2)
                {
                    int[,] COS = new int[string1.Length + 1, string2.Length + 1];
                    for (int i = 1; i <= string1.Length; i++)
                        for (int j = 1; j <= string2.Length; j++)
                        {
                            if (string1[i - 1] == string2[j - 1])
                                COS[i, j] = (COS[i - 1, j - 1]) + 1;
                            else
                                if (COS[i - 1, j] > COS[i, j - 1])
                                    COS[i, j] = COS[i - 1, j];
                                else
                                COS[i, j] = COS[i, j - 1];
                        }
                    return COS;
                }
        static void Wypisz(string string1, string string2, int[,] arr)
        {
            Console.Write("  _  ");
            for (int i = 0; i < string1.Length; i++)
                Console.Write(string1[i] + "  ");
            Console.WriteLine();
            for (int i = 0; i <= string2.Length; i++){

                if (i == 0)Console.Write("_ ");
                else Console.Write(string2[i - 1] + " ");

                for (int j = 0; j <= string1.Length; j++)
                    Console.Write(arr[j, i] + "  ");
                
                Console.WriteLine();
            }
        }

        static void Main(string[] args)
        {
            string string1 = "OKNOD";
            string string2 = "ONOKNO";
            int[,] arr = NajWspPod(string1, string2);
            Wypisz(string1, string2, arr);
            Console.WriteLine(WypiszNajWspPod(arr, string1, string2, string1.Length, string2.Length));
            Console.ReadKey();
            Console.ReadLine();
        }
    }
}
