﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        /*
         * Lekcja: [ Algorytm Dijkstry ]  i Kopiec?
         * https://pl.wikipedia.org/wiki/Algorytm_Dijkstry
         * Graf z tego
         * 
         * 1  2  3  4  5  6
         * =  7  9  n  n  14          n - Nan
         *    =  9  22 n  14
         *       =  20 n  11   
         *          20 20  =
         *          =  20 
         *             =
         * 1 3 4
         * 
         * Krok 1.
         * Patrze na tabeli na zmiane liczb
         * w 4 zmiana jest na 22->20
         * biore liczbe ktora konczy sie na nowej liczby czyli 3 (20 jest w tej samej lini co = w "3" )
         * Krok.2 
         * 3 sie nie zmienia od poczatku wiec bierzemy pierwsz liczbe ktora sie konczy, czyli liczba od ktorej zaczynamy droge / koniec.
         * 
         * 
         * 
         * 
         * */
        public Form1()
        {
            InitializeComponent();
        }

    }
    class Graf // ?
    {
        //to gdzie ?
        public Dictionary<Node, Para> tabela;
        public List<Node> odwiedzone;

        public Graf(Dictionary<Node, Para> tabela, List<Node> odwiedzone)
        {
            this.tabela = tabela;
            this.odwiedzone = odwiedzone;
        }
        //
        void ZnajdzNastepnyElementDoPrzeszukania ()
        {
            // to w petli true while
            var element = tabela.OrderBy(x => x.Value.odleglosc).First(x => !this.odwiedzone.Contains(x.Key)); //sortowanie po odleglosci (gdzie to? )
            if (element.Key != null && element.Value != null) // ? lub element != null ToDo: czy dziala
            {
                //spr Node -> element.Key , element.Value.odleglosc
                // this.odwiedzone.Add(element.Key);  chyba
            }
            /*
             *          tabela.ContainKey(...);
             * 
             * 
             * */
        }

    }
    class Para
    {
        public Node poprzednik;
        public int odleglosc;
        public Para (Node p, int odl)
        {
            this.poprzednik = p;
            this.odleglosc = odl;
        }

    }

    class Node
    {
        public int wartosc; //nazwa?
    }
}
