﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lekcja_4
{
    class Drzewo //: IAiSD
    {
        public Wezel korzen;
        public int length;
        public int glebokosc;

        public Drzewo(int wartosc)
        {
            this.korzen = new Wezel(wartosc);
            this.korzen.wartosc = wartosc;
            this.length = 1;
            this.glebokosc = 0;
        }
        Wezel ZnajdzRodzica(int numer)
        {
            List <int> droga = new List<int>();
            while (numer > 0)
            {
                numer = numer / 2;
                droga.Add(numer);
            }
            droga.Reverse();
            var rodzic = this.korzen;
            for (int i = 1;i < droga.Count;i++) {
                if (droga[i] % 2 == 1 )
                {
                    rodzic = rodzic.prawe;
                }
                else
                {
                    rodzic = rodzic.prawe;
                }
            }
            return rodzic;
        }
        public void Push(int wartosc)
        {
            var rodzic = this.ZnajdzRodzica(this.length);
            var dziecko = new Wezel(wartosc);
            dziecko.rodzic = rodzic;
            if (this.length % 2 == 1)
            {
                rodzic.lewe = dziecko;
            }
            else
            {
                rodzic.prawe = dziecko;
            }
            this.length++;
            //sprawdzi glebokosc
            /*
                      0      -0
                    1  2     -1
                   3 4 5 6   -2

            jak sprawdzic i ew. powiekszyc glebokosc
                      */
             /* 
              - POP
             
              - WYSWIETLANIE (TREE VIEW )  (ew. odswiezanie drzewa po dodaniu)
             */
        }
    }
}
