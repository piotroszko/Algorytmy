﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        //Algorytm Kruskala
        /*
         * https://pl.wikipedia.org/wiki/Algorytm_Kruskala
         * 
         * 1. Sortowanie krawedzi (po wadze)
         * 2.  (pierwsza krawedz od razu dodac do pierwszego podgrafu)
         * 3. Stosunek do krawedzi (sprawdz krawedz do kazdego grafu) jezeli 0 to od razu breake i wywalamy krawedz;
         * 4. Jezeli sprawdzKrawedz zwroci 1 to dodajemy do danego grafu dana krawedz i brakujacy wierzcholek, =>>>
         * jezeli 2 grafy zwroca 1 to laczymy te grafy (chyba?: po dodaniu do 1 dana krawedz)
         * 
         * To wszystko w 2 petlach ( na kazda krawedz i na kazdy podgraf (foreach dla obu))
         * */

        public Form1()
        {
            InitializeComponent();
        }
    }
    class Node
    {
        public int wartosc;
        public Node(int wartosc)
        {
            this.wartosc = wartosc;
        }
    }
    class Krawedz
    {
        public Node node1;
        public Node node2;
        public int waga;
    }
    class Graf
    {
        public List<Node> listaNode;
        public List<Krawedz> listaKrawedzi;

        public Graf(List<Node> listaNode, List<Krawedz> listaKrawedzi)
        {
            this.listaNode = listaNode;
            this.listaKrawedzi = listaKrawedzi;
        }
        public void polaczGrafy(Graf g)
        {
            this.listaKrawedzi.AddRange(g.listaKrawedzi);
            this.listaNode.AddRange(g.listaNode);
        }
        public int sprawdzKrawedz(Krawedz k)
        {
            int wynik = 0;
            if (!this.listaNode.Contains(k.node1))
            {
                wynik++;
            }
            if (!this.listaNode.Contains(k.node2))
            {
                wynik++;
            }
            //0 - olewam krawedz
            //1 - dodaj krawedz i wierzcholek
            //2 - nowy graf i dodaj 1 krawedz i 2 wierzcholki
            return wynik;
        }

        //wypisz liste krawedzi i liste nodeow
    }
    class Kruskal
    {
        // orderby znajdywanie najmniejej wagi krawedzi z Graf.listaKrawedzi;
        public Graf graf1;
        public List<Node> pelnaListaNode;
        public List<Krawedz> pelnaListaKrawedzi;
        public List<Graf> podGrafy;

        public Kruskal(Graf graf1, List<Graf> podGrafy)
        {
            this.graf1 = graf1;
            this.pelnaListaNode = graf1.listaNode;
            this.pelnaListaKrawedzi = graf1.listaKrawedzi;
            this.podGrafy = podGrafy;
        }

        public Graf algorytm ()
        {
            this.pelnaListaKrawedzi.OrderBy(Krawedz => Krawedz.waga);

            // pierwszy element
            List<Node> nodeList = new List<Node>();
            nodeList.Add(this.pelnaListaKrawedzi[0].node1);
            nodeList.Add(this.pelnaListaKrawedzi[0].node2);
            List<Krawedz> krawedzList = new List<Krawedz>();
            krawedzList.Add(this.pelnaListaKrawedzi[0]);
            this.pelnaListaKrawedzi.RemoveAt(0);
            this.podGrafy.Add(new Graf(nodeList, krawedzList));


            foreach (Krawedz kTmp in this.pelnaListaKrawedzi)
            {
                // dla kazdego podgrafu metoda sprawdzKrawedz i w zaleznosci od tego podejmuje decyzje
            }

        }
    }
}
