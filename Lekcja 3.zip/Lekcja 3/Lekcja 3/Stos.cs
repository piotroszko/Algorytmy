﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lekcja_3
{
    class Stos : SD,JAiSD
    {

        public int Pop()
        {
            throw new NotImplementedException();
        }

    }
}
