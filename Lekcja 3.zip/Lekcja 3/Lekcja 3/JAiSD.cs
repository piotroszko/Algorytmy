﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lekcja_3
{
    interface JAiSD
    {
        int Length {get;}
        void push(int a);
        int Pop();
    }
}
