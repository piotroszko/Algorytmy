﻿using System;

public class instrument
{
	public void Gray()
	{

	}
}
