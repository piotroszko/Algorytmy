﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lekcja_3
{
    abstract class SD
    {
        public int Length => this.dane.Length;
        public void push(int a)
        {
            int[] nowa = this.PrzepiszPush();
            nowa[nowa.Length - 1] = a;
            this.dane = nowa;
        }
        private int[] dane;
        public SD()
        {
            this.dane = new int[0];
        }
        protected int[] PrzepiszPush()
        {
            int[] tablicaNowa = new int[this.dane.Length+1];
            for (int i = 0; i < this.dane.Length; i++)
            {
                tablicaNowa[i] = this.dane[i];
            }
            return tablicaNowa;
        }
        public int this[int index]
        {
            get { return this.dane[index]; }
            set { this.dane[index] = value; }
        }
    }
}
