﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            /*
            List<Node> nody = new List<Node>();
            nody.Add(new Node("A")); //0
            nody.Add(new Node("B")); //1
            nody.Add(new Node("C")); //2
            nody.Add(new Node("D")); //3
            nody.Add(new Node("E")); //4
            List<Krawedz> krawedzie = new List<Krawedz>();
            krawedzie.Add(new Krawedz(nody[0],nody[4],1));
            krawedzie.Add(new Krawedz(nody[2], nody[3],2));
            krawedzie.Add(new Krawedz(nody[0], nody[1], 3));
            krawedzie.Add(new Krawedz(nody[1], nody[4], 4));
            krawedzie.Add(new Krawedz(nody[1], nody[2], 5));
            krawedzie.Add(new Krawedz(nody[2], nody[4], 6));
            krawedzie.Add(new Krawedz(nody[3], nody[4], 7));
            Graf graf1 = new Graf(nody, krawedzie);

            Kruskal k1 = new Kruskal(graf1);
            k1.graf1.wypiszGraf();
            k1.algorytm();
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine("");
            Console.WriteLine(" Po zastosowaniu algorytmu: ");
            k1.podGrafy[0].wypiszGraf();
            */
            Console.ReadKey();
        }
    }
    class Node
    {
        public string nazwa;
        public Node(string nazwa)
        {
            this.nazwa = nazwa;
        }
    }
    class Krawedz
    {
        public Node node1;
        public Node node2;
        public int waga;

        public Krawedz(Node node1, Node node2, int waga)
        {
            this.node1 = node1;
            this.node2 = node2;
            this.waga = waga;
        }
    }
    class Graf
    {
        public List<Node> listaNode;
        public List<Krawedz> listaKrawedzi;
        public Graf(List<Node> listaNode, List<Krawedz> listaKrawedzi)
        {
            this.listaNode = listaNode;
            this.listaKrawedzi = listaKrawedzi;
        }
        public void polaczGrafy(Graf g)
        {
            foreach (Node n in g.listaNode)
            {
                if (!this.listaNode.Contains(n)) this.listaNode.Add(n);
            }
            foreach (Krawedz k in g.listaKrawedzi)
            {
                if (!this.listaKrawedzi.Contains(k)) this.listaKrawedzi.Add(k);
            }
        }

        public void wypiszGraf()
        {
            Console.WriteLine("Lista wierzcholkow: ");
            foreach (Node n in this.listaNode)
            {
                Console.WriteLine("- " + n.nazwa);
            }
            Console.WriteLine("Lista krawedzi: ");
            foreach (Krawedz k in this.listaKrawedzi)
            {
                Console.WriteLine(" " + k.node1.nazwa + " :: " + k.node2.nazwa + "      Wartosc krawedzi:" + k.waga );
            }

        }

    }
    class AlgorytmPrim
    {
        public Graf grafGlowny;
        public List<Krawedz> listaKoncoweDrzewo;
        public List<Node> listaKoncoweNode;

        public AlgorytmPrim(Graf grafGlowny)
        {
            this.grafGlowny = grafGlowny;
            this.listaKoncoweDrzewo = new List<Krawedz>();
            this.listaKoncoweNode = new List<Node>();
        }
        public List<Krawedz> zwrocKrawedzie(Node nTmp)
        {
            List<Krawedz> kList = new List<Krawedz>();
            foreach (Krawedz k in grafGlowny.listaKrawedzi)
            {
                if (k.node1 == nTmp || k.node2 == nTmp)
                {
                    kList.Add(k);
                }
            }
            return kList;
        }
        public void Algorytm()
        {
            List<Krawedz> tmpListaKrawdzi = new List<Krawedz>();

            if (this.grafGlowny.listaKrawedzi.Count == 0) return;
            if (this.grafGlowny.listaNode.Count == 0) return;

            Node startowyNode = grafGlowny.listaNode[0];
            Node aktualnyNode = startowyNode;

            while (true) // dodac odpowiedni warunek wyjscia
            {
                if (aktualnyNode != null)
                {
                    tmpListaKrawdzi = zwrocKrawedzie(aktualnyNode);
                }
                tmpListaKrawdzi.OrderBy(Krawedz => Krawedz.waga);
                if (tmpListaKrawdzi[0] != null)
                {
                    if (tmpListaKrawdzi[0].node1 == aktualnyNode)
                    {
                        aktualnyNode = tmpListaKrawdzi[0].node2;
                    }
                    else
                    {
                        aktualnyNode = tmpListaKrawdzi[0].node1;
                    }
                }

            }
        }
    }
}
